#!/usr/bin/env python3
"""Downloads only the 65 unique Minshawi verses for inclusion in the offline APK.
This is a BUILD step. The installed app has no Internet permission.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, subprocess, time, urllib.request

base=Path(__file__).resolve().parents[1]
sources=[
  'https://verse.mp3quran.net/data/Minshawy_Murattal_128kbps/',
  'https://everyayah.com/data/Minshawy_Murattal_128kbps/',
]
files=json.loads((base/'scripts/verses.json').read_text('utf-8'))['unique_files']
out=base/'app/src/main/assets/audio';out.mkdir(parents=True,exist_ok=True)

def is_mp3(data):
    return len(data)>20000 and (data[:3]==b'ID3' or (data[0]==255 and (data[1]&224)==224))

def fetch(name):
    dest=out/name
    if dest.exists() and is_mp3(dest.read_bytes()):return name,'already present',dest.stat().st_size
    for attempt in range(4):
        for root in sources:
            try:
                req=urllib.request.Request(root+name,headers={'User-Agent':'OfflineRuqyahBuilder/1.0'})
                with urllib.request.urlopen(req,timeout=35) as r: data=r.read()
                if not is_mp3(data):raise ValueError('Response is not a valid sized MP3')
                temp=dest.with_suffix('.tmp');temp.write_bytes(data);temp.replace(dest)
                return name,'downloaded',len(data)
            except Exception:
                pass
        time.sleep((attempt+1)*2)
    raise RuntimeError(f'Could not obtain verse audio: {name}')

failures=[];bytecount=0
with ThreadPoolExecutor(max_workers=4) as pool:
    tasks={pool.submit(fetch, f):f for f in files}
    for t in as_completed(tasks):
        try:
            name,status,size=t.result();bytecount+=size
            print(f'[{status}] {name}: {size:,} bytes',flush=True)
        except Exception as error:
            failures.append(str(error));print('ERROR:',str(error),flush=True)
if failures:
    raise SystemExit('Missing recordings: '+', '.join(failures))
print(f'OK: {len(files)} recorded MP3 files, total {bytecount/1024/1024:.1f} MiB')
