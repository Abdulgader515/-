package org.ruqyah.minshawi;

import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;
import androidx.media3.common.Player;

public class PlaybackService extends MediaSessionService {
    private MediaSession mediaSession;
    @Override public void onCreate() {
        super.onCreate();
        ExoPlayer player = new ExoPlayer.Builder(this).build();
        player.setMediaItems(PlaylistFactory.items());
        player.setRepeatMode(Player.REPEAT_MODE_OFF);
        mediaSession = new MediaSession.Builder(this,player).build();
    }
    @Override public MediaSession onGetSession(MediaSession.ControllerInfo info) {
        return mediaSession;
    }
    @Override public void onDestroy(){
        if(mediaSession!=null){
            mediaSession.getPlayer().release();
            mediaSession.release();
            mediaSession=null;
        }
        super.onDestroy();
    }
}
