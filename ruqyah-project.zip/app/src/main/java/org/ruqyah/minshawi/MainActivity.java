package org.ruqyah.minshawi;

import android.app.Activity;
import android.content.ComponentName;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Locale;

public class MainActivity extends Activity {
    private MediaController controller;
    private ListenableFuture<MediaController> controllerFuture;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextView title, verse, progress;
    private SeekBar seek;
    private Button play;
    private LinearLayout chapterList;
    private boolean isDragging=false;
    private final Runnable tick=new Runnable(){ public void run(){refresh(); handler.postDelayed(this,650);} };
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved); setContentView(R.layout.activity_main);
        title=findViewById(R.id.currentTitle);
        verse=findViewById(R.id.currentVerse);
        progress=findViewById(R.id.progressLabel);
        seek=findViewById(R.id.seek);
        play=findViewById(R.id.play);
        chapterList=findViewById(R.id.chapterList);
        play.setOnClickListener(v->{
            if(controller==null){Toast.makeText(this,"جار تجهيز المشغل",Toast.LENGTH_SHORT).show();return;}
            if(controller.isPlaying()) controller.pause();
            else {
                if(controller.getPlaybackState()==Player.STATE_ENDED){controller.seekTo(0,0);}
                controller.prepare();controller.play();
            }
            refresh();
        });
        findViewById(R.id.previous).setOnClickListener(v->{
            if(controller!=null){int n=controller.getCurrentMediaItemIndex();controller.seekTo(Math.max(0,n-1),0);controller.prepare();controller.play();}
        });
        findViewById(R.id.next).setOnClickListener(v->{
            if(controller!=null){int n=controller.getCurrentMediaItemIndex();controller.seekTo(Math.min(PlaylistFactory.total()-1,n+1),0);controller.prepare();controller.play();}
        });
        findViewById(R.id.restart).setOnClickListener(v->{
            if(controller!=null){controller.seekTo(0,0);controller.prepare();controller.play();}
        });
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onStartTrackingTouch(SeekBar bar){isDragging=true;}
            @Override public void onProgressChanged(SeekBar bar,int value,boolean fromUser){}
            @Override public void onStopTrackingTouch(SeekBar bar){
                if(controller!=null&&controller.getDuration()>0){
                    controller.seekTo((controller.getDuration()*bar.getProgress())/1000L);
                }
                isDragging=false;
            }
        });
        createChapterButtons();
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class));
        controllerFuture=new MediaController.Builder(this,token).buildAsync();
        controllerFuture.addListener(()->{
            try {
                controller=controllerFuture.get();
                controller.addListener(new Player.Listener(){@Override public void onEvents(Player p, Player.Events events){refresh();}});
                refresh();
            } catch(Exception e){
                Toast.makeText(this,"تعذر بدء المشغل: "+e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }, command->handler.post(command));
        handler.post(tick);
    }
    private GradientDrawable background(int color,int border){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));d.setStroke(dp(1),border);return d;
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private void createChapterButtons(){
        int[] starts=PlaylistFactory.starts();
        for(int i=0;i<PlaylistFactory.GROUPS.length;i++){
            final int index=starts[i];
            PlaylistFactory.Group g=PlaylistFactory.GROUPS[i];
            Button b=new Button(this);
            b.setAllCaps(false);
            b.setText((i+1)+".  "+g.title+"\n"+g.start+"–"+g.end+"  •  عدد التكرار: "+g.repeat);
            b.setTextColor(Color.WHITE);b.setTextSize(17);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
            b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            b.setPadding(dp(17),dp(14),dp(17),dp(14));
            b.setBackground(background(Color.rgb(22,54,62),Color.rgb(60,104,103)));
            b.setMinHeight(dp(75));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
            lp.bottomMargin=dp(10);b.setLayoutParams(lp);
            b.setOnClickListener(v->{
                if(controller!=null){controller.seekTo(index,0);controller.prepare();controller.play();}
            });
            chapterList.addView(b);
        }
    }
    private void refresh(){
        if(controller==null){return;}
        int idx=Math.max(0,controller.getCurrentMediaItemIndex());
        int[] info=PlaylistFactory.findInfo(idx);
        PlaylistFactory.Group g=PlaylistFactory.GROUPS[info[0]];
        title.setText(g.title);
        verse.setText("الآية "+info[1]+"   •   التكرار "+info[2]+" من "+g.repeat);
        progress.setText("الآية "+(idx+1)+" من "+PlaylistFactory.total());
        play.setText(controller.isPlaying()?"❚❚ إيقاف":"▶ تشغيل");
        long duration=controller.getDuration(), position=controller.getCurrentPosition();
        if(!isDragging){seek.setProgress(duration>0?(int)Math.min(1000,1000.0*position/duration):0);}
    }
    @Override protected void onDestroy(){
        handler.removeCallbacks(tick);
        if(controllerFuture!=null){MediaController.releaseFuture(controllerFuture);}
        super.onDestroy();
    }
}
