package org.ruqyah.minshawi;

import android.content.Context;
import android.net.Uri;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PlaylistFactory {
    public static class Group {
        public final String title;
        public final int surah, start, end, repeat;
        Group(String title, int surah, int start, int end, int repeat) {
            this.title=title; this.surah=surah; this.start=start; this.end=end; this.repeat=repeat;
        }
    }
    public static final Group[] GROUPS = {
    new Group("سورة الفاتحة",1,1,7,7),
new Group("بداية سورة البقرة",2,1,5,1),
new Group("سورة البقرة: 163-164",2,163,164,1),
new Group("آية الكرسي",2,255,255,1),
new Group("خواتيم سورة البقرة",2,285,286,1),
new Group("سورة آل عمران: 18",3,18,18,7),
new Group("سورة الأعراف: 54-56",7,54,56,1),
new Group("سورة البقرة: 102",2,102,102,1),
new Group("سورة المؤمنون: 115-118",23,115,118,1),
new Group("سورة الصافات: 1-10",37,1,10,1),
new Group("سورة الرحمن: 33-36",55,33,36,1),
new Group("سورة الحشر: 21-24",59,21,24,1),
new Group("سورة القلم: 51-52",68,51,52,7),
new Group("سورة النساء: 54",4,54,54,7),
new Group("سورة الإسراء: 82",17,82,82,7),
new Group("سورة الأنبياء: 69-70",21,69,70,7),
new Group("سورة الإخلاص",112,1,4,3),
new Group("سورة الفلق",113,1,5,3),
new Group("سورة الناس",114,1,6,3)
    };

    public static int[] starts() {
        int[] result=new int[GROUPS.length];
        int sum=0;
        for(int i=0;i<GROUPS.length;i++){
            result[i]=sum;
            Group g=GROUPS[i];
            sum += (g.end-g.start+1)*g.repeat;
        }
        return result;
    }
    public static int total() {
        int sum=0;
        for (Group g : GROUPS) sum+=(g.end-g.start+1)*g.repeat;
        return sum;
    }
    public static List<MediaItem> items() {
        List<MediaItem> list = new ArrayList<>();
        for (Group g : GROUPS) {
            for(int r=1;r<=g.repeat;r++) {
                for(int v=g.start;v<=g.end;v++) {
                    String file=String.format(Locale.ROOT,"%03d%03d.mp3",g.surah,v);
                    Uri uri=Uri.parse("asset:///audio/"+file);
                    MediaMetadata md=new MediaMetadata.Builder()
                        .setTitle(g.title+" — الآية "+v+" ("+r+" من "+g.repeat+")")
                        .setArtist("محمد صديق المنشاوي")
                        .setAlbumTitle("آيات الرقية الشرعية")
                        .build();
                    list.add(new MediaItem.Builder().setUri(uri).setMediaId(file+"-"+r)
                         .setMediaMetadata(md).build());
                }
            }
        }
        return list;
    }
    public static int[] findInfo(int index){
        int offset=0;
        for(int g=0;g<GROUPS.length;g++){
            Group group=GROUPS[g];
            int count=group.end-group.start+1;
            int total=count*group.repeat;
            if(index<offset+total){
                int local=index-offset;
                return new int[]{g,group.start+(local%count),1+(local/count)};
            }
            offset+=total;
        }
        return new int[]{0,1,1};
    }
    private PlaylistFactory() {}
}
