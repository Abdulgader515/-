This folder must contain 65 MP3 files downloaded by scripts/download_audio.py before building the APK.
The Android app plays them offline from assets via asset:///audio/NNNNNN.mp3.
